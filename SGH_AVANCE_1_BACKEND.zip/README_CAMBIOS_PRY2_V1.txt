Cambios respecto al backend del proyecto 1 en este GIT:
+ Se añade una tabla usuarios donde se registra el IdUsuario (Identity PK), PasswordHash para la contraseña y CorreoUsuario (Correo de registro que es ÚNICO)
  Además de un Bit que se encarga de saber si ese usuario es administrador o no y si está activo (Por si hubiera proceso de desactivación antes de
  un proceso de eliminación de usuario). Se tiene una FK ligada a IdUsuario desde las siguientes tablas: Empresas, Cliente.

+ Se añade la normalización de las provincias, cantones y distritos en sus respectivas tablas. Siguen esta lógica: Un distrito pertenece a un cantón, pero pueden 
  haber varios cantones con un distrito del mismo nombre. Por esto mismo, el Id de cada una de las tablas es crucial, así como su check unique que es compuesto por
  el nombre del distrito y el Id del cantón, o bien, por el nombre del cantón y el Id de provincia. Asegurando que solo haya un distrito por cantón con ese mismo nombre, 
  y un solo cantón por provincia con un mismo nombre. A partir de estos Id se puede calcular estos 3 atributos desde IdDistrito, pues tiene una FK a Cantones, que a su vez
  tiene un FK a Provincias. IdDistrito fue añadido en Empresas y en Cliente y se retiraron las columnas Provincia, Canton, Distrito de estas ultimas 2 tablas mencionadas.

+ Checks para el formato de los números de teléfono, de forma que sean sin guiones ni espacios para evitar ambigüedades, con un "+" al principio para el código de país
  y con longitudes entre los 8 y los 16 dígitos (Ejemplo: +506########).

+ Checks para el formato del correo (que siempre tengan al menos un "@" y un punto).

+Algunos Stored Procedures que pueden utilizarse para modificar la información y actividad de los usuarios, datos de empresas y datos de clientes.