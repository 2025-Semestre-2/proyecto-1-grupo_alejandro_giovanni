CREATE PROCEDURE sp_LoginUsuario
    @CorreoUsuario NVARCHAR(254)
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        U.IdUsuario,
        U.CorreoUsuario,
        U.PasswordHash,
        U.EsAdministrador,
        CASE
            WHEN EXISTS (SELECT 1 FROM Empresas E WHERE E.IdUsuario = U.IdUsuario) THEN 'EMPRESA'
            WHEN EXISTS (SELECT 1 FROM Clientes C WHERE C.IdUsuario = U.IdUsuario) THEN 'CLIENTE'
            ELSE 'ADMIN'
        END AS TipoUsuario
    FROM Usuarios U
    WHERE U.CorreoUsuario = @CorreoUsuario
      AND U.Activo = 1;
END;
GO

CREATE PROCEDURE sp_CrearUsuario
    @CorreoUsuario NVARCHAR(254),
    @PasswordHash NVARCHAR(255),
    @EsAdministrador BIT = 0
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Usuarios (CorreoUsuario, PasswordHash, EsAdministrador)
    VALUES (@CorreoUsuario, @PasswordHash, @EsAdministrador);

    SELECT SCOPE_IDENTITY() AS IdUsuario;
END;
Go


CREATE PROCEDURE sp_CrearCliente
    @ClienteId INT,
    @IdUsuario INT,
    @Nombre NVARCHAR(120),
    @Apellido1 NVARCHAR(120),
    @Apellido2 NVARCHAR(120),
    @FechaNacimiento DATE,
    @TipoIdentificacionId INT,
    @NumeroIdentificacion NVARCHAR(50),
    @PaisResidencia NVARCHAR(100),
    @IdDistrito INT,
    @Telefono1 NVARCHAR(20),
    @Telefono2 NVARCHAR(20),
    @CorreoContacto NVARCHAR(254)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Cliente(ClienteId, IdUsuario, Nombre, Apellido1, Apellido2, FechaNacimiento,
    TipoIdentificacionId, NumeroIdentificacion, PaisResidencia, IdDistrito,
    Telefono1, Telefono2, CorreoContacto)
    VALUES (@ClienteId, @IdUsuario, @Nombre, @Apellido1, @Apellido2, @FechaNacimiento,
    @TipoIdentificacionId, @NumeroIdentificacion, @PaisResidencia, @IdDistrito,
    @Telefono1, @Telefono2, @CorreoContacto);
END;
Go

CREATE PROCEDURE sp_CrearEmpresa
    @CedulaJuridica NVARCHAR(50),
    @IdUsuario INT,
    @Nombre NVARCHAR(200),
    @TipoEmpresaId INT,
    @CorreoContacto NVARCHAR(254),
    @Telefono NVARCHAR(20),
    @SitioWeb NVARCHAR(300),
    @IdDistrito INT,
    @Barrio NVARCHAR(100) ,
    @SenasExactas NVARCHAR(400),  
    @Latitud DECIMAL(9,6),
    @Longitud DECIMAL(9,6)
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO Empresas(CedulaJuridica, IdUsuario, Nombre, TipoEmpresaId, CorreoContacto,
    Telefono, SitioWeb, IdDistrito, Barrio, SenasExactas, Latitud, Longitud)
    VALUES (@CedulaJuridica, @IdUsuario, @Nombre, @TipoEmpresaId, @CorreoContacto,
    @Telefono, @SitioWeb, @IdDistrito, @Barrio, @SenasExactas, @Latitud, @Longitud);
END;
Go

-- (OP) Para uso nuestro (hacer perfil de admin)
CREATE PROCEDURE sp_AsignarAdministrador
    @IdUsuario INT
AS
BEGIN
    UPDATE Usuarios
    SET EsAdministrador = 1
    WHERE IdUsuario = @IdUsuario;
END;
Go


CREATE PROCEDURE sp_DesactivarUsuario
    @IdUsuario INT
AS
BEGIN
    UPDATE Usuarios
    SET Activo = 0
    WHERE IdUsuario = @IdUsuario;
END;
Go

